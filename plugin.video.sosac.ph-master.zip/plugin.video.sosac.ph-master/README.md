# plugin.video.sosac.ph

[![Code Climate](https://codeclimate.com/github/kodi-czsk/plugin.video.sosac.ph/badges/gpa.svg)
](https://codeclimate.com/github/kodi-czsk/plugin.video.sosac.ph)
